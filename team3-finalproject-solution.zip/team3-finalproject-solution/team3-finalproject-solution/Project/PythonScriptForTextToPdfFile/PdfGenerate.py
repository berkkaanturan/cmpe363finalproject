# Python program to create
# a pdf file
 
 
from fpdf import FPDF
 
 
# save FPDF() class into a
# variable pdf
pdf = FPDF()
 
# Add a page
pdf.add_page()
 
# set style and size of font
# that you want in the pdf
pdf.set_font("Arial", size = 15)
 
# create a cell
pdf.cell(200, 10, txt = "The Title",
         ln = 1, align = 'C')
 
# add another cell
pdf.cell(200, 10, txt = "Enter Your 1111",
         ln = 2, align = 'L')
pdf.cell(200, 10, txt = "Enter Your 2222222",
         ln = 2, align = 'L')
 
pdf.cell(200, 10, txt = "Enter Your 33333",
         ln = 2, align = 'L')
 
pdf.cell(200, 10, txt = "Enter Your 444",
         ln = 2, align = 'L')
pdf.cell(200, 10, txt = "Enter Your 11115555",
         ln = 2, align = 'L')
 
pdf.cell(200, 10, txt = "Enter Your blabla",
         ln = 2, align = 'L')
 
pdf.cell(200, 10, txt = "Enter Your hamburger",
         ln = 2, align = 'L')
 
pdf.cell(200, 10, txt = "pizza",
         ln = 2, align = 'L')
 
# save the pdf with name .pdf
pdf.output("Generated.pdf") 